import express from 'express';

import receiveApi from '../api/receive';

const router = express.Router();

export default router;